
import 'package:flutter/material.dart';

import 'addQuickInfoModel.dart';
import 'common.dart';
import 'httpService.dart';
import 'quickAddModel.dart';

class QuickAdd extends StatefulWidget {
  String? token;
  QuickAdd(this.token);

  @override
  _QuickAddState createState() => _QuickAddState();
}

class _QuickAddState extends State<QuickAdd> {
  TextEditingController name = new TextEditingController();
  TextEditingController contact1 = new TextEditingController();
  TextEditingController projectName = new TextEditingController();
  TextEditingController projectCost = new TextEditingController();
  TextEditingController advance = new TextEditingController();
  var projectType;

  AddQuickInfoModel? quickInfo;

  void initState() {
    // TODO: implement initState
    super.initState();
    getData();

  }

  getData() async {
    quickInfo = await HttpService.addQuickInfo();

    if (quickInfo != null) {
      setState(() {});
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.lightBlue,
          leading: IconButton(
              icon: Icon(Icons.arrow_back, color: Colors.black),
              onPressed: () => Navigator.of(context).pop()),
          title: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Quick Add',
                style: TextStyle(
                  color: Colors.black,
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
        ),
        body: quickInfo!=null?Stack(
          children: [
            SingleChildScrollView(
              child: Column(
                children: [
                  textFeildFunction('Client Name', name, TextInputType.text),
                  textFeildFunction(
                      'Contact Number 1', contact1, TextInputType.text),
                  textFeildFunction(
                      'Project Name', projectName, TextInputType.text),
                  Padding(
                    padding:
                    const EdgeInsets.only(left: 24, right: 10, top: 10),
                    child: FormField<String>(
                      builder: (FormFieldState<String> state) {
                        return Container(
                          height: MediaQuery.of(context).size.height * 0.07,
                          width: MediaQuery.of(context).size.width * 0.9,
                          decoration: BoxDecoration(
                            color: Colors.white,
                            border: Border.all(
                              color: Colors.black,
                            ),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: DropdownButtonHideUnderline(
                            child: DropdownButton<String>(
                              isExpanded: true,
                              hint: Padding(
                                padding: const EdgeInsets.only(left: 20),
                                child: Text('Project Type'),
                              ),
                              value: projectType,
                              items: quickInfo!.data!.projectTypes!.map((data) {
                                return DropdownMenuItem(
                                  value: data.id.toString(),
                                  child: Padding(
                                    padding: const EdgeInsets.only(left: 20),
                                    child: Text(data.typeName.toString()),
                                  ),
                                );
                              }).toList(),
                              onChanged: (newValue) {
                                setState(() {
                                  projectType = newValue;
                                });
                                print(projectType);
                              },
                            ),
                          ),
                        );
                      },
                    ),
                  ),


                  textFeildFunction('Project Cost', projectCost, TextInputType.text),
                  textFeildFunction(
                      'Advance Received', advance, TextInputType.text),

                  SizedBox(
                    height: 90,
                  )
                ],
              ),
            ),
            Align(
              child: Padding(
                padding: const EdgeInsets.all(0),
                child: Container(
                  height: 50,
                  width: MediaQuery.of(context).size.width * 7,
                  color: Colors.white,
                  child: FlatButton(
                    color: Colors.green,
                    onPressed: () async {
                       if (name.text.isEmpty) {
                      Common.toastMessaage(
                      'Client Name cannot be empty', Colors.red);
                      }
                       else if (contact1.text.isEmpty) {
                         Common.toastMessaage(
                             'Contact1  cannot be empty', Colors.red);
                       }
                       else if (projectName.text.isEmpty) {
                         Common.toastMessaage(
                             'Project Name  cannot be empty', Colors.red);
                       }
                      else if (projectType == null) {
                        Common.toastMessaage(
                            'Choose Project Type', Colors.red);
                      }
                       else if (projectCost.text.isEmpty) {
                         Common.toastMessaage(
                             'Project Name  cannot be empty', Colors.red);
                       }



                      else
                      {
                        Common.showProgressDialog(context, "Loading..");

                        QuickAddModel object =
                        await HttpService.quickAdd(name.text,contact1.text,projectName.text,projectType,projectCost.text,advance.text,widget.token
                        );
                        if (object.status == true) {
                          Common.toastMessaage(
                              'Added Successfully', Colors.green);
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => QuickAdd(widget.token)),
                          );
                        } else {
                          Navigator.pop(context);
                          Common.toastMessaage(
                              'Something Went Wrong', Colors.red);
                        }

                      }
                    },
                    child: Text(
                      'Submit',
                      style: TextStyle(
                          color: Colors.black,
                          fontWeight: FontWeight.bold,
                          fontSize: 20),
                    ),
                  ),
                ),
              ),
              alignment: Alignment.bottomCenter,
            ),
          ],
        ):AlertDialog(
          content: Flex(
            direction: Axis.horizontal,
            children: <Widget>[
              CircularProgressIndicator(),
              Padding(
                padding: EdgeInsets.only(left: 15),
              ),
              Flexible(
                  flex: 8,
                  child: Text(
                    'Wait..',
                    style: TextStyle(
                        fontSize: 16, fontWeight: FontWeight.bold),
                  )),
            ],
          ),
        ));
  }

  textFeildFunction(hintname, controller, keyboardType) {
    return Padding(
      padding: const EdgeInsets.only(left: 15, top: 10),
      child: Padding(
        padding: const EdgeInsets.only(left: 10, right: 10),
        child: Center(
          child: TextFormField(
              controller: controller,
              keyboardType: keyboardType,
              decoration: InputDecoration(
                labelText: hintname,
                fillColor: Colors.white,
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide(
                    color: Colors.blue,
                  ),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide(
                    color: Colors.black,
                    width: 1.0,
                  ),
                ),
              )),
        ),
      ),
    );
  }
}
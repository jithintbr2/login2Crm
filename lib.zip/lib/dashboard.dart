import 'package:crm_admin/accounts.dart';
import 'package:crm_admin/clientList.dart';
import 'package:crm_admin/dashboardModel.dart';
import 'package:crm_admin/httpService.dart';
import 'package:crm_admin/projectList.dart';
import 'package:crm_admin/quickAdd.dart';
import 'package:crm_admin/staffList.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class Dashboard extends StatefulWidget {
  String? token;

  Dashboard(this.token);

  @override
  _DashboardState createState() => _DashboardState();
}

class _DashboardState extends State<Dashboard> {
  DashboardModel? dashboardDetails;

  void initState() {
    // TODO: implement initState
    super.initState();
    getData();
  }

  getData() async {
    dashboardDetails = await HttpService.dashboard(widget.token);
    if (dashboardDetails != null) {
      setState(() {});
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: dashboardDetails != null
          ? SafeArea(
              child: SingleChildScrollView(
                child: Column(
                  children: [
                    SizedBox(
                      height: 100,
                    ),
                    GridView.builder(
                      physics: const NeverScrollableScrollPhysics(),
                      shrinkWrap: true,
                      gridDelegate:
                          const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 4,
                        mainAxisSpacing: 8,
                      ),
                      padding: EdgeInsets.zero,
                      itemCount: dashboardDetails!.data!.menus!.length,
                      itemBuilder: (BuildContext context, index) {
                        return InkWell(
                          onTap: () async {
                            if (dashboardDetails!.data!.menus![index].activePg
                                    .toString() ==
                                'projects') {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) =>
                                        ProjectList(widget.token)),
                              );
                            } else if (dashboardDetails!
                                    .data!.menus![index].activePg
                                    .toString() ==
                                'staffs') {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) =>
                                        StaffList(widget.token)),
                              );
                            } else if (dashboardDetails!
                                    .data!.menus![index].activePg
                                    .toString() ==
                                'clients') {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) =>
                                        ClientList(widget.token)),
                              );
                            } else if (dashboardDetails!
                                    .data!.menus![index].activePg
                                    .toString() ==
                                'accounts') {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => Accounts(
                                        dashboardDetails!
                                            .data!.menus![index].id,
                                        widget.token)),
                              );
                            }
                            else if (dashboardDetails!
                                .data!.menus![index].activePg
                                .toString() ==
                                'quick_insert') {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => QuickAdd(widget.token)),
                              );
                            }
                          },
                          child: GestureDetector(
                            child: Container(
                              constraints: const BoxConstraints(
                                maxHeight: 81,
                              ),
                              child: Column(
                                children: [
                                  Container(
                                    constraints: const BoxConstraints(
                                      minHeight: 56,
                                      minWidth: 56,
                                      maxHeight: 69,
                                      maxWidth: 69,
                                    ),
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(12),
                                      image: DecorationImage(
                                          fit: BoxFit.cover,
                                          image: AssetImage(
                                              'assets/images/project1.jpg')),
                                    ),
                                  ),
                                  const SizedBox(
                                    height: 4,
                                  ),
                                  Expanded(
                                    child: Text(
                                      dashboardDetails!
                                          .data!.menus![index].menuTitle
                                          .toString(),
                                      style: TextStyle(
                                          fontWeight: FontWeight.bold),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        );
                      },
                    ),
                    SizedBox(
                      height: 24,
                    ),
                    Padding(
                      padding: const EdgeInsets.only(left: 20, right: 20),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            'Work Status',
                            style: TextStyle(
                                fontSize: 18, fontWeight: FontWeight.bold),
                          ),
                          Text(
                            'View all',
                          ),
                        ],
                      ),
                    ),
                    SizedBox(
                      height: 18,
                    ),

                    ListView.separated(
                        physics: NeverScrollableScrollPhysics(),
                        shrinkWrap: true,
                        itemCount:dashboardDetails!.data!.staff!.length,
                        itemBuilder: (context, index) => Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Padding(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 12, vertical: 8),
                                  child: Row(
                                    children: [
                                      CircleAvatar(
                                        backgroundImage: NetworkImage(
                                          dashboardDetails!.data!
                                              .staff![index].staffImage
                                              .toString(),
                                        ),
                                        radius: 25,
                                      ),
                                      SizedBox(width:20),
                                      Text(dashboardDetails!.data!.staff![index].name.toString(),
                                          style:
                                          TextStyle(fontWeight: FontWeight.bold,)),

                                    ],
                                  )),
                              dashboardDetails!.data!.staff![index].active==true?SizedBox(
                                  height: 170,

                                  child: ListView.builder(
                                      itemBuilder: (_, int childIndex) {
                                        return  Padding(
                                          padding: const EdgeInsets.only(left:3),
                                          child: Container(


                                            height: 150,width: 300,
                                            child: Card(
                                              //color: Color.fromARGB(70, 22, 44, 33),
                                              child: Padding(
                                                padding: const EdgeInsets.only(top: 20,left: 20),
                                                child: GestureDetector(
                                                  onTap: () {},
                                                  child: Padding(
                                                    padding: const EdgeInsets.only(bottom: 16),
                                                    child: Container(
                                                      color: Colors.transparent,
                                                      height: 100,
                                                      width: MediaQuery.of(context).size.width - 32,
                                                      child: Row(
                                                        crossAxisAlignment: CrossAxisAlignment.stretch,
                                                        children: [

                                                          Flexible(
                                                            child: Column(
                                                              crossAxisAlignment:
                                                              CrossAxisAlignment.start,
                                                              children: [

                                                                Expanded(
                                                                  child: Text(
                                                                    'Project: ' +
                                                                        dashboardDetails!.data!.staff![index]
                                                                            .timeline![childIndex].project
                                                                            .toString(),
                                                                    overflow: TextOverflow.ellipsis,style:TextStyle(color: Colors.black,fontWeight: FontWeight.bold),
                                                                  ),
                                                                ),
                                                                Expanded(
                                                                  child: Text(
                                                                    'Module :' +
                                                                        dashboardDetails!.data!.staff![index]
                                                                            .timeline![childIndex].activity
                                                                            .toString(),style:TextStyle(color: Colors.black,fontWeight: FontWeight.bold),
                                                                  ),
                                                                ),
                                                                Expanded(
                                                                  child: Text(
                                                                    'Sub Module :' +
                                                                        dashboardDetails!.data!.staff![index]
                                                                            .timeline![childIndex].subTask
                                                                            .toString(),style:TextStyle(color: Colors.black,fontWeight: FontWeight.bold),
                                                                  ),
                                                                ),
                                                                Expanded(
                                                                  child: Text(
                                                                    'Remarks : ' +
                                                                        dashboardDetails!.data!.staff![index]
                                                                            .timeline![childIndex].remarks
                                                                            .toString(),style:TextStyle(color: Colors.black,fontWeight: FontWeight.bold),
                                                                    overflow: TextOverflow.ellipsis,
                                                                  ),
                                                                ),

                                                                Expanded(
                                                                  child: Text(
                                                                    dashboardDetails!.data!.staff![index]
                                                                        .timeline![childIndex].timeString
                                                                        .toString(),
                                                                    overflow: TextOverflow.ellipsis,
                                                                    maxLines: 1,
                                                                    style: TextStyle(
                                                                        color: dashboardDetails!
                                                                            .data!.staff![index]
                                                                            .timeline![childIndex]
                                                                            .isActive
                                                                            .toString() ==
                                                                            'N'
                                                                            ? Colors.green
                                                                            : Colors.red,
                                                                        fontWeight: FontWeight.bold),
                                                                  ),
                                                                ),
                                                                Expanded(
                                                                  child: Container(
                                                                    width: 100,
                                                                    decoration: dashboardDetails!.data!.staff![index]
                                                                        .timeline![childIndex].status
                                                                        .toString()=='Ongoing'?BoxDecoration(
                                                                      color: Colors.red,borderRadius: BorderRadius.circular(5),
                                                                    ):BoxDecoration(
                                                                      color: Colors.green,borderRadius: BorderRadius.circular(5),
                                                                    ),
                                                                    child: Center(
                                                                      child: Text(dashboardDetails!.data!.staff![index]
                                                                          .timeline![childIndex].status
                                                                          .toString(),style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold),
                                                                        overflow: TextOverflow.ellipsis,
                                                                      ),
                                                                    ),
                                                                  ),
                                                                ),
                                                                const Spacer(),
                                                              ],
                                                            ),
                                                          )
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        );
                                      },
                                      itemCount:dashboardDetails!.data!.staff![index].timeline!.length,
                                      scrollDirection: Axis.horizontal,
                                      shrinkWrap: true,
                                      padding:
                                      EdgeInsets.symmetric(horizontal: 10))):SizedBox(height: 60,child: Center(child: Text('Didnt Start Work Till Yet..',style: TextStyle(color: Colors.red,fontWeight: FontWeight.bold,fontSize: 15),)),)
                            ]),
                        separatorBuilder: (_, __) => SizedBox(height: 0))
                  ],
                ),
              ),
            )
          : AlertDialog(
              content: Flex(
                direction: Axis.horizontal,
                children: <Widget>[
                  CircularProgressIndicator(),
                  Padding(
                    padding: EdgeInsets.only(left: 15),
                  ),
                  Flexible(
                      flex: 8,
                      child: Text(
                        'Wait..',
                        style: TextStyle(
                            fontSize: 16, fontWeight: FontWeight.bold),
                      )),
                ],
              ),
            ),
    );
  }
}


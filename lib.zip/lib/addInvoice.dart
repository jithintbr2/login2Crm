
import 'package:flutter/material.dart';

import 'addInvoiceInfoModel.dart';
import 'addInvoiceModel.dart';
import 'clientProjectsModel.dart';
import 'common.dart';
import 'httpService.dart';

class AddInvoice extends StatefulWidget {
  String? token;
  AddInvoice(this.token);


  @override
  _AddInvoiceState createState() => _AddInvoiceState();
}

class _AddInvoiceState extends State<AddInvoice> {
  TextEditingController invoiceNumber = new TextEditingController();
  TextEditingController remarks = new TextEditingController();
  TextEditingController totalAmount = new TextEditingController(text: '0');
  var client;
   AddInvoiceInfoModel? invoiceInfo;
  ClientProjectsModel? clientProjects;
   bool val = false;
   List<checkBoxClass>? listItems;
   List<checkBoxClass> checkedItems = [];
  //
   int? totalPrice = 0;
   List<checkBoxClass>? ids;
   bool clientVal=false;
  void initState() {
    // TODO: implement initState


    super.initState();
    getData();
    listItems = [];
  }

  getData() async {
    invoiceInfo = await HttpService.addInvoiceInfo();
    invoiceNumber = new TextEditingController(text:invoiceInfo!.data!.invoiceId.toString());

    if (invoiceInfo != null) {

      setState(() {});
    }
  }
  getClientProjects(clientId) async {

    clientProjects = await HttpService.clientProjects(clientId);


    if (clientProjects != null) {

      clientProjects!.data!.projects!.forEach((element) {
        listItems!.add(checkBoxClass(
            element.projectAmount,
            element.projectName.toString(),
            element.projectId));
      });

      setState(() {});
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.lightBlue,
          leading: IconButton(
              icon: Icon(Icons.arrow_back, color: Colors.black),
              onPressed: () => Navigator.of(context).pop()),
          title: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Add Invoice',
                style: TextStyle(
                  color: Colors.black,
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
        ),
        body: invoiceInfo!=null?Stack(
          children: [
            SingleChildScrollView(

              child: Column(

                children: [
                  textFeildFunction('Invoice Number', invoiceNumber, TextInputType.text),
                  Padding(
                    padding:
                    const EdgeInsets.only(left: 24, right: 10, top: 10),
                    child: FormField<String>(
                      builder: (FormFieldState<String> state) {
                        return Container(
                          height: MediaQuery.of(context).size.height * 0.07,
                          width: MediaQuery.of(context).size.width * 0.9,
                          decoration: BoxDecoration(
                            color: Colors.white,
                            border: Border.all(
                              color: Colors.black,
                            ),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: DropdownButtonHideUnderline(
                            child: DropdownButton<String>(
                              isExpanded: true,
                              hint: Padding(
                                padding: const EdgeInsets.only(left: 20),
                                child: Text('Client Name'),
                              ),
                              value: client,
                              items: invoiceInfo!.data!.clientList!.map((data) {
                                return DropdownMenuItem(
                                  value: data.clientId.toString(),
                                  child:
                                  Padding(
                                    padding: const EdgeInsets.only(left: 20),
                                    child: Text(data.clientName.toString()),
                                  ),
                                  // onTap: (){
                                  //   setState(() {
                                  //     data.projects!.forEach((element) {
                                  //       listItems!.add(checkBoxClass(
                                  //           element.projectAmount,
                                  //           element.projectName.toString(),
                                  //           element.projectId));
                                  //     });
                                  //   });
                                  // },

                                );
                              }).toList(),
                              onChanged: (newValue) {
                                setState(() {
                                  client = newValue;
                                  listItems = [];
                                  getClientProjects(client);
                                  clientVal=true;


                                });
                                print(client);
                              },
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                  if(listItems!.length>0)
                    Padding(
                      padding: const EdgeInsets.only(left: 20,right: 10,top: 20,bottom: 20),
                      child:mainItems(),
                    ),


                  textFeildFunction(
                      'Total Amount', totalAmount, TextInputType.text),
                  textFeildFunction('Remarks', remarks, TextInputType.text),

                  SizedBox(
                    height: 90,
                  )
                ],
              ),
            ),
            Align(
              child: Padding(
                padding: const EdgeInsets.all(0),
                child: Container(
                  height: 50,
                  width: MediaQuery.of(context).size.width * 7,
                  color: Colors.white,
                  child: FlatButton(
                    color: Colors.green,
                    onPressed: () async {
                      if (invoiceNumber.text.isEmpty) {
                        Common.toastMessaage(
                            'Invoice Number Can not Empty', Colors.red);
                      } else if (client == null) {
                        Common.toastMessaage(
                            'Choose Client Name', Colors.red);
                      } else if (checkedItems.length==0) {
                        Common.toastMessaage(
                            'choose Atleast One Project', Colors.red);
                      }
                      else if (checkedItems.length==0) {
                        Common.toastMessaage(
                            'choose Atleast One Project', Colors.red);
                      }
                      else if (totalAmount.text.isEmpty) {
                        Common.toastMessaage(
                            'Amount can not Empty', Colors.red);
                      }
                      else{

                        Map<String, dynamic> body = {
                          "token": widget.token,
                          "clientId":client,
                          "projectIds": checkedItems
                          .map((e) => e.ids)
                          .toList(),
                          "total_amount": totalAmount.text,
                          "remark": remarks.text,



                        };
                        AddInvoiceModel object =
                        await HttpService.addInvoice(body);
                        if (object.status == true) {
                          Common.toastMessaage(
                              'Added Successfully', Colors.green);
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => AddInvoice(widget.token
                                   )),
                          );
                        } else {
                          Navigator.pop(context);
                          Common.toastMessaage(
                              'Something Went Wrong', Colors.red);
                        }
                        print(body);

                      }

                    },
                    child: Text(
                      'Submit',
                      style: TextStyle(
                          color: Colors.black,
                          fontWeight: FontWeight.bold,
                          fontSize: 20),
                    ),
                  ),
                ),
              ),
              alignment: Alignment.bottomCenter,
            ),
          ],
        ):AlertDialog(
          content: Flex(
            direction: Axis.horizontal,
            children: <Widget>[
              CircularProgressIndicator(),
              Padding(
                padding: EdgeInsets.only(left: 15),
              ),
              Flexible(
                  flex: 8,
                  child: Text(
                    'Wait..',
                    style: TextStyle(
                        fontSize: 16, fontWeight: FontWeight.bold),
                  )),
            ],
          ),
        ),);
  }

  textFeildFunction(hintname, controller, keyboardType) {
    return Padding(
      padding: const EdgeInsets.only(left: 15, top: 10),
      child: Padding(
        padding: const EdgeInsets.only(left: 10, right: 10),
        child: Center(
          child: TextFormField(
              controller: controller,
              keyboardType: keyboardType,
              decoration: InputDecoration(
                labelText: hintname,
                fillColor: Colors.white,
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide(
                    color: Colors.blue,
                  ),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide(
                    color: Colors.black,
                    width: 1.0,
                  ),
                ),
              )),
        ),
      ),
    );
  }
  mainItems() {
    return ListView.builder(
      shrinkWrap: true,
      physics: NeverScrollableScrollPhysics(),
      itemBuilder: (context, index) {
        return  chekBox(listItems![index]);
      },
      itemCount: listItems!.length,
    );
  }
  chekBox(checkBoxClass obj) {
    return Card(
      child:Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [

          Expanded(child:
          CheckboxListTile(
            title:Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  obj.title.toString(),
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
                ),
                Text(
                  obj.price.toString() + '/-',
                  style: TextStyle(
                      color: Colors.black,
                      fontWeight: FontWeight.bold,
                      fontSize: 15),
                ),
              ],
            ),value: checkedItems.contains(obj) ? true : false,
            onChanged: (bool? value) {
              if (value==true) {
                setState(() {
                  totalPrice = 0;
                  checkedItems.add(obj);
                  checkedItems.forEach((element){

                    totalPrice = (int.parse(element.price)+totalPrice!);
                    totalAmount =TextEditingController(text: totalPrice.toString());
                  });
                });
              } else {
                setState(() {
                    totalPrice = 0;
                    checkedItems.remove(obj);
                    checkedItems.forEach((element){
                      totalPrice = (int.parse(element.price)+totalPrice!);
                      totalAmount = TextEditingController(text: totalPrice.toString());
                    });
                  });

              }
              print(totalAmount.text);

            },

            controlAffinity: ListTileControlAffinity.leading,
          ),
          )

        ],
      ),




    );
  }
}
class checkBoxClass {
  checkBoxClass(this.price, this.title, this.ids,{this.chheckval: false});

  int? ids;
  bool? chheckval;
  String? title;
  var price;

  getChlk() {
    return chheckval;
  }

  gettitle() {
    return title;
  }

  getPrice() {
    return price;
  }

  updateChk(val) {
    chheckval = val;
  }
}
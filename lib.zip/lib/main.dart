import 'package:crm_admin/splashScreen.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(
    MaterialApp(home:SplashScreen()),);
}

import 'package:flutter/material.dart';

import 'httpService.dart';
import 'receiptListModel.dart';

class ReceiptList extends StatefulWidget {
  String? token;
  ReceiptList(this.token);


  @override
  _ReceiptListState createState() => _ReceiptListState();
}

class _ReceiptListState extends State<ReceiptList> {
  ReceiptListModel? receiptList;

  void initState() {
    // TODO: implement initState
    super.initState();
    getData();
  }

  getData() async {
    receiptList = await HttpService.receiptList(widget.token);
    if (receiptList != null) {
      setState(() {});
    }
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.lightBlue,
          leading: IconButton(
              icon: Icon(Icons.arrow_back, color: Colors.black),
              onPressed: () =>Navigator.of(context).pop()
          ),
          title: Text(
            'Receipt',
            style: TextStyle(
              color: Colors.black,
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
        body: receiptList != null
            ?Stack(
              children: [
                ListView.builder(
                    physics: const ClampingScrollPhysics(),
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 24),
                    itemCount: receiptList!.data!.receipt!.length,
                    itemBuilder: (BuildContext context, int index) {
                      return GestureDetector(


                        onTap: () => {
                          // Navigator.push(
                          //   context,
                          //   MaterialPageRoute(builder: (context) => ProjectDetails(projectList!.data!.projectList![index].projectId,widget.token)),
                          // ),
                        },
                        child: Container(
                          margin: const EdgeInsets.only(bottom: 12),
                          padding: const EdgeInsets.only(top: 16),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(5),
                            color: Colors.white,
                            boxShadow: [
                              BoxShadow(
                                color: Colors.grey.withOpacity(0.5),
                                spreadRadius: 4,
                                blurRadius: 6,
                                offset: const Offset(1, 1),
                              ),
                            ],
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Padding(
                                padding: const EdgeInsets.fromLTRB(16, 0, 16, 13),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: [
                                        Padding(
                                          padding: const EdgeInsets.only(bottom: 16.0),
                                          child: Text(
                                            receiptList!.data!.receipt![index].receiptNo.toString(),
                                            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                                          ),
                                        ),
                                        Padding(
                                          padding: const EdgeInsets.only(bottom: 16.0),
                                          child: Text(
                                              receiptList!.data!.receipt![index].invoiceNo.toString(),
                                            style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
                                          ),
                                        ),
                                      ],
                                    ),
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,

                                      children: [
                                        Expanded(
                                          flex: 1,
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              info(receiptList!.data!.receipt![index].client.toString(),),
                                              info(receiptList!.data!.receipt![index].dateOfReceipt.toString(),),


                                            ],
                                          ),
                                        ),
                                        Expanded(
                                          flex: 1,
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Text(
                                          '₹ '+receiptList!.data!.receipt![index].paidAmount.toString(),
                                                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold,color: Colors.green),
                                              ),
                                              info('collected By : '+receiptList!.data!.receipt![index].collectedBy.toString(),),


                                            ],
                                          ),
                                        ),


                                      ],
                                    ),

                                  ],
                                ),
                              ),

                            ],
                          ),
                        ),
                      );
                    }),
                SizedBox(height: 100,),
                Align(
                  child: Padding(
                    padding: const EdgeInsets.all(0),
                    child: Container(
                      height: 50,
                      width: MediaQuery.of(context).size.width * 7,
                      color: Colors.blueGrey,
                      child: Center(child: Text('Total Amount :  ₹ '+ receiptList!.data!.totalAmount.toString(),style: TextStyle(fontSize: 18,color: Colors.white,fontWeight: FontWeight.bold),)),
                    ),
                  ),
                  alignment: Alignment.bottomCenter,
                ),
              ],
            ):AlertDialog(
          content: Flex(
            direction: Axis.horizontal,
            children: <Widget>[
              CircularProgressIndicator(),
              Padding(
                padding: EdgeInsets.only(left: 15),
              ),
              Flexible(
                  flex: 8,
                  child: Text(
                    'Wait..',
                    style: TextStyle(
                        fontSize: 16, fontWeight: FontWeight.bold),
                  )),
            ],
          ),
        ),
    );
  }
}
Widget label(String labelName, {Color color = const Color(0xff757575)}) {
  return Text(
    labelName,
    style: TextStyle(
      color: color,
      fontSize: 14,
      fontWeight: FontWeight.w500,
    ),
  );
}

Widget info(String infoText, {Color color = Colors.black}) {
  return Padding(
    padding: const EdgeInsets.symmetric(vertical: 6.0),
    child: Text(
      infoText,
      style: TextStyle(
        color: color,
        fontSize: 14,
        fontWeight: FontWeight.bold,
      ),
    ),
  );
}

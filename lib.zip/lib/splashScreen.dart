import 'dart:async';
import 'package:crm_admin/common.dart';
import 'package:crm_admin/dashboard.dart';
import 'package:crm_admin/login.dart';
import 'package:flutter/material.dart';

class SplashScreen extends StatefulWidget {
  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  final splashDelay = 2;

  void initState() {
    super.initState();
    _loadWidget();
  }

  _loadWidget() async {
    var _duration = Duration(seconds: splashDelay);
    // return '';
    // return Timer(_duration, navigationPage);
    return Timer(_duration, routeTOHomePage);
  }

  @override
  Widget build(BuildContext context) {
    return Container(
        color: Colors.white,
        width: MediaQuery.of(context).size.width * 0.8,
        child: Center(
          child: Image.asset(
            'assets/images/logo.png',
            width: 200,
          ),
        ));
  }

  routeTOHomePage() async {
    String? token = await Common.getSharedPref("token");
    print(token);


    if (token != null)
      Navigator.of(context).pushAndRemoveUntil(
          MaterialPageRoute(builder: (context) => Dashboard(token)),
          (Route<dynamic> route) => false);
    else
      Navigator.of(context).pushAndRemoveUntil(
          MaterialPageRoute(builder: (context) => Login()),
          (Route<dynamic> route) => false);
  }
}

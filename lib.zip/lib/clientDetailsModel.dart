class ClientDetailsModel {
  bool? status;
  String? message;
  Data? data;

  ClientDetailsModel({this.status, this.message, this.data});

  ClientDetailsModel.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    message = json['message'];
    data = json['data'] != null ? new Data.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['status'] = this.status;
    data['message'] = this.message;
    if (this.data != null) {
      data['data'] = this.data!.toJson();
    }
    return data;
  }
}

class Data {
  int? clientId;
  String? clientName;
  String? address1;
  String? address2;
  String? contact1;
  String? contact2;
  String? contactPerson;
  String? designation;
  String? email;
  String? description;
  String? remarks;
  String? clientCategory;
  String? clientType;
  List<Projects>? projects;

  Data(
      {this.clientId,
        this.clientName,
        this.address1,
        this.address2,
        this.contact1,
        this.contact2,
        this.contactPerson,
        this.designation,
        this.email,
        this.description,
        this.remarks,
        this.clientCategory,
        this.clientType,
        this.projects});

  Data.fromJson(Map<String, dynamic> json) {
    clientId = json['clientId'];
    clientName = json['clientName'];
    address1 = json['address1'];
    address2 = json['address2'];
    contact1 = json['contact1'];
    contact2 = json['contact2'];
    contactPerson = json['contact_person'];
    designation = json['designation'];
    email = json['email'];
    description = json['description'];
    remarks = json['remarks'];
    clientCategory = json['client_category'];
    clientType = json['client_type'];
    if (json['projects'] != null) {
      projects = <Projects>[];
      json['projects'].forEach((v) {
        projects!.add(new Projects.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['clientId'] = this.clientId;
    data['clientName'] = this.clientName;
    data['address1'] = this.address1;
    data['address2'] = this.address2;
    data['contact1'] = this.contact1;
    data['contact2'] = this.contact2;
    data['contact_person'] = this.contactPerson;
    data['designation'] = this.designation;
    data['email'] = this.email;
    data['description'] = this.description;
    data['remarks'] = this.remarks;
    data['client_category'] = this.clientCategory;
    data['client_type'] = this.clientType;
    if (this.projects != null) {
      data['projects'] = this.projects!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Projects {
  int? projectId;
  String? projectName;
  String? clientName;
  String? statusName;
  String? startDate;
  String? completedDate;
  String? timeLeft;

  Projects(
      {this.projectId,
        this.projectName,
        this.clientName,
        this.statusName,
        this.startDate,
        this.completedDate,
        this.timeLeft});

  Projects.fromJson(Map<String, dynamic> json) {
    projectId = json['projectId'];
    projectName = json['projectName'];
    clientName = json['clientName'];
    statusName = json['statusName'];
    startDate = json['startDate'];
    completedDate = json['completedDate'];
    timeLeft = json['timeLeft'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['projectId'] = this.projectId;
    data['projectName'] = this.projectName;
    data['clientName'] = this.clientName;
    data['statusName'] = this.statusName;
    data['startDate'] = this.startDate;
    data['completedDate'] = this.completedDate;
    data['timeLeft'] = this.timeLeft;
    return data;
  }
}
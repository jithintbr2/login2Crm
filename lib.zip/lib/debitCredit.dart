
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class DebitCredit extends StatefulWidget {


  @override
  _DebitCreditState createState() => _DebitCreditState();
}

class _DebitCreditState extends State<DebitCredit> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.lightBlue,
        leading: IconButton(
            icon: Icon(Icons.arrow_back, color: Colors.black),
            onPressed: () => Navigator.of(context).pop()),
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              'Debit Credit',
              style: TextStyle(
                color: Colors.black,
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),

          ],
        ),
      ),
      body: Stack(
        children: [
          SingleChildScrollView(
            scrollDirection: Axis.vertical,
            child: DataTable(columns: [
              DataColumn(label: Text('Date1')),
              DataColumn(label: Text('Date2')),
              DataColumn(label: Text('Date3')),
              DataColumn(label: Text('Date4')),
              DataColumn(label: Text('Date5')),
              DataColumn(label: Text('Date6')),
              DataColumn(label: Text('Date7')),
              DataColumn(label: Text('Date8')),
            ],
            rows: [
              DataRow(cells:[DataCell(Text('a')),DataCell(Text('a')),DataCell(Text('a')),DataCell(Text('a')),DataCell(Text('a')),DataCell(Text('a')),DataCell(Text('a')),DataCell(Text('a'))]),
            ],),
          ),


        ],
      ),);
  }
}

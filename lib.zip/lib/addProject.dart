import 'package:date_time_picker/date_time_picker.dart';
import 'package:flutter/material.dart';

import 'addProjectInfoModel.dart';
import 'addProjectModel.dart';
import 'common.dart';
import 'httpService.dart';

class AddProject extends StatefulWidget {
  String? token;

  AddProject(this.token);

  @override
  _AddProjectState createState() => _AddProjectState();
}

class _AddProjectState extends State<AddProject> {
  TextEditingController projectName = new TextEditingController();
  TextEditingController description = new TextEditingController();
  TextEditingController cost = new TextEditingController();
  TextEditingController remarks = new TextEditingController();
  TextEditingController totalAmount = new TextEditingController();
  TextEditingController paidAmount = new TextEditingController();

  var client;
  var projectType;
  var status;
  String? estimatedFromDate;
  String? estimatedToDate;
  bool isGst = false;
  bool isInvoice = false;

  AddProjectInfoModel? clientInfo;

  void initState() {
    // TODO: implement initState
    super.initState();
    getData();
  }

  getData() async {
    clientInfo = await HttpService.addProjectInfo();

    if (clientInfo != null) {
      setState(() {});
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.lightBlue,
          leading: IconButton(
              icon: Icon(Icons.arrow_back, color: Colors.black),
              onPressed: () => Navigator.of(context).pop()),
          title: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Add Project',
                style: TextStyle(
                  color: Colors.black,
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
        ),
        body: clientInfo != null
            ? Stack(
                children: [
                  SingleChildScrollView(
                    child: Column(
                      children: [
                        textFeildFunction('Project Name', projectName,
                            TextInputType.text, true),
                        Padding(
                          padding: const EdgeInsets.only(
                              left: 24, right: 10, top: 10),
                          child: FormField<String>(
                            builder: (FormFieldState<String> state) {
                              return Container(
                                height:
                                    MediaQuery.of(context).size.height * 0.07,
                                width: MediaQuery.of(context).size.width * 0.9,
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  border: Border.all(
                                    color: Colors.black,
                                  ),
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: DropdownButtonHideUnderline(
                                  child: DropdownButton<String>(
                                    isExpanded: true,
                                    hint: Padding(
                                      padding: const EdgeInsets.only(left: 20),
                                      child: Text('Client Name'),
                                    ),
                                    value: client,
                                    items:
                                        clientInfo!.data!.clients!.map((data) {
                                      return DropdownMenuItem(
                                        value: data.clientId.toString(),
                                        child: Padding(
                                          padding: const EdgeInsets.only(left: 20),
                                          child: Text(data.clientName.toString()),
                                        ),
                                      );
                                    }).toList(),
                                    onChanged: (newValue) {
                                      setState(() {
                                        client = newValue;
                                      });
                                      print(client);
                                    },
                                  ),
                                ),
                              );
                            },
                          ),
                        ),
                        Row(
                          children: [
                            Padding(
                              padding: const EdgeInsets.only(
                                  left: 24, right: 10, top: 10),
                              child: FormField<String>(
                                builder: (FormFieldState<String> state) {
                                  return Container(
                                    height: MediaQuery.of(context).size.height *
                                        0.07,
                                    width:
                                        MediaQuery.of(context).size.width * 0.4,
                                    decoration: BoxDecoration(
                                      color: Colors.white,
                                      border: Border.all(
                                        color: Colors.black,
                                      ),
                                      borderRadius: BorderRadius.circular(8),
                                    ),
                                    child: DropdownButtonHideUnderline(
                                      child: DropdownButton<String>(
                                        isExpanded: true,
                                        hint: Padding(
                                          padding:
                                              const EdgeInsets.only(left: 20),
                                          child: Text('Project Type'),
                                        ),
                                        value: projectType,
                                        items: clientInfo!.data!.projectTypes!
                                            .map((data) {
                                          return DropdownMenuItem(
                                            value: data.ptId.toString(),
                                            child: Padding(
                                              padding: const EdgeInsets.only(left: 20),
                                              child: Text(data.ptName.toString()),
                                            ),
                                          );
                                        }).toList(),
                                        onChanged: (newValue) {
                                          setState(() {
                                            projectType = newValue;
                                          });
                                          print(projectType);
                                        },
                                      ),
                                    ),
                                  );
                                },
                              ),
                            ),
                            Padding(
                              padding:
                                  const EdgeInsets.only(right: 10, top: 10),
                              child: FormField<String>(
                                builder: (FormFieldState<String> state) {
                                  return Container(
                                    height: MediaQuery.of(context).size.height *
                                        0.07,
                                    width: MediaQuery.of(context).size.width *
                                        0.45,
                                    decoration: BoxDecoration(
                                      color: Colors.white,
                                      border: Border.all(
                                        color: Colors.black,
                                      ),
                                      borderRadius: BorderRadius.circular(8),
                                    ),
                                    child: DropdownButtonHideUnderline(
                                      child: DropdownButton<String>(
                                        isExpanded: true,
                                        hint: Padding(
                                          padding:
                                              const EdgeInsets.only(left: 20),
                                          child: Text('Status'),
                                        ),
                                        value: status,
                                        items: clientInfo!.data!.statuses!
                                            .map((data) {
                                          return DropdownMenuItem(
                                            value: data.statusId.toString(),
                                            child: Padding(
                                              padding: const EdgeInsets.only(left: 20),
                                              child: Text(
                                                  data.statusName.toString()),
                                            ),
                                          );
                                        }).toList(),
                                        onChanged: (newValue) {
                                          setState(() {
                                            status = newValue;
                                          });
                                          print(status);
                                        },
                                      ),
                                    ),
                                  );
                                },
                              ),
                            ),
                          ],
                        ),
                        textFeildFunction('Description', description,
                            TextInputType.text, true),
                        Padding(
                          padding: const EdgeInsets.only(
                              left: 24, right: 10, top: 10, bottom: 10),
                          child: Row(
                            children: [
                              Container(
                                height:
                                    MediaQuery.of(context).size.height * 0.07,
                                width: MediaQuery.of(context).size.width * 0.43,
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  border: Border.all(
                                    color: Colors.black,
                                  ),
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: Center(
                                  child: DateTimePicker(
                                    initialValue: estimatedFromDate,

                                    // initialValue or controller.text can be null, empty or a DateTime string otherwise it will throw an error.
                                    type: DateTimePickerType.date,
                                    dateHintText: 'From Date',
                                    //controller: fromDate,
                                    firstDate: DateTime(1995),
                                    lastDate:
                                        DateTime.now().add(Duration(days: 365)),
                                    // This will add one year from current date
                                    validator: (value) {
                                      return null;
                                    },
                                    onChanged: (value) {
                                      if (value.isNotEmpty) {
                                        setState(() {
                                          estimatedFromDate = value;
                                        });
                                      }
                                    },
                                    // We can also use onSaved
                                    onSaved: (value) {
                                      if (value!.isNotEmpty) {
                                        estimatedFromDate = value;
                                      }
                                    },
                                  ),
                                ),
                              ),
                              SizedBox(
                                width: 10,
                              ),
                              Container(
                                height:
                                    MediaQuery.of(context).size.height * 0.07,
                                width: MediaQuery.of(context).size.width * 0.43,
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  border: Border.all(
                                    color: Colors.black,
                                  ),
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: Center(
                                  child: DateTimePicker(
                                    initialValue: estimatedToDate,
                                    // initialValue or controller.text can be null, empty or a DateTime string otherwise it will throw an error.
                                    type: DateTimePickerType.date,
                                    dateHintText: 'To date',

                                    //controller: toDate,
                                    firstDate: DateTime(1995),
                                    lastDate:
                                        DateTime.now().add(Duration(days: 365)),
                                    // This will add one year from current date
                                    validator: (value) {
                                      return null;
                                    },
                                    onChanged: (value) {
                                      if (value.isNotEmpty) {
                                        setState(() {
                                          estimatedToDate = value;
                                        });
                                      }
                                    },
                                    // We can also use onSaved
                                    onSaved: (value) {
                                      if (value!.isNotEmpty) {
                                        estimatedToDate = value;
                                      }
                                    },
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        textFeildFunction(
                            'Project Cost', cost, TextInputType.number, true),
                        CheckboxListTile(
                          title: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                'is GST',
                                style: TextStyle(fontSize: 15),
                              ),
                            ],
                          ),
                          value: isGst,
                          onChanged: (bool? value) {
                            if (value == true) {
                              setState(() {
                                isGst = true;
                                String? gstAmount =
                                    (int.parse(cost.text) * 18 / 100 +
                                            int.parse(cost.text))
                                        .toString();
                                //String? totAmount=(int.parse(gstAmount)+int.parse(cost.text)).toString();

                                totalAmount =
                                    new TextEditingController(text: gstAmount);

                                // totalAmount= (int.parse(cost.text)*18/100) as TextEditingController;
                              });
                            } else {
                              setState(() {
                                isGst = false;
                              });
                            }
                            print(isGst);
                          },
                          controlAffinity: ListTileControlAffinity.leading,
                        ),
                        if (isGst == true)
                          textFeildFunction('Total Cost', totalAmount,
                              TextInputType.number, false),
                        textFeildFunction(
                            'Remarks', remarks, TextInputType.text, true),
                        CheckboxListTile(
                          title: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                'Generate Invoice',
                                style: TextStyle(fontSize: 15),
                              ),
                            ],
                          ),
                          value: isInvoice,
                          onChanged: (bool? value) {
                            if (value == true) {
                              setState(() {
                                isInvoice = true;
                              });
                            } else {
                              setState(() {
                                isInvoice = false;
                              });
                            }
                            print(isInvoice);
                          },
                          controlAffinity: ListTileControlAffinity.leading,
                        ),
                        if (isInvoice == true)
                          textFeildFunction('Paid Amount', paidAmount,
                              TextInputType.number, true),
                        SizedBox(
                          height: 90,
                        )
                      ],
                    ),
                  ),
                  Align(
                    child: Padding(
                      padding: const EdgeInsets.all(0),
                      child: Container(
                        height: 50,
                        width: MediaQuery.of(context).size.width * 7,
                        color: Colors.white,
                        child: FlatButton(
                          color: Colors.green,
                          onPressed: () async {
                            if (projectName.text.isEmpty) {
                              Common.toastMessaage(
                                  'Project Name cannot be empty', Colors.red);
                            } else if (client == null) {
                              Common.toastMessaage('Choose Client', Colors.red);
                            } else if (projectType == null) {
                              Common.toastMessaage(
                                  'Choose Project Type', Colors.red);
                            } else if (status == null) {
                              Common.toastMessaage(
                                  'Choose Project Status', Colors.red);
                            } else if (cost.text.isEmpty) {
                              Common.toastMessaage(
                                  'Project Cost cannot be empty', Colors.red);
                            } else {
                              Common.showProgressDialog(context, "Loading..");

                              AddProjectModel object =
                                  await HttpService.addProjects(
                                      projectName.text,
                                      client,
                                      description.text,
                                      cost.text,
                                      remarks.text,
                                      totalAmount.text,
                                      paidAmount.text,
                                      projectType,
                                      status,
                                      estimatedFromDate,
                                      estimatedToDate,
                                      isGst,
                                      isInvoice,
                                      widget.token);
                              if (object.status == true) {
                                Common.toastMessaage(
                                    'Added Successfully', Colors.green);
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) =>
                                          AddProject(widget.token)),
                                );
                              } else {
                                Navigator.pop(context);
                                Common.toastMessaage(
                                    'Something Went Wrong', Colors.red);
                              }
                            }
                          },
                          child: Text(
                            'Submit',
                            style: TextStyle(
                                color: Colors.black,
                                fontWeight: FontWeight.bold,
                                fontSize: 20),
                          ),
                        ),
                      ),
                    ),
                    alignment: Alignment.bottomCenter,
                  ),
                ],
              )
            : AlertDialog(
                content: Flex(
                  direction: Axis.horizontal,
                  children: <Widget>[
                    CircularProgressIndicator(),
                    Padding(
                      padding: EdgeInsets.only(left: 15),
                    ),
                    Flexible(
                        flex: 8,
                        child: Text(
                          'Wait..',
                          style: TextStyle(
                              fontSize: 16, fontWeight: FontWeight.bold),
                        )),
                  ],
                ),
              ));
  }

  textFeildFunction(hintname, controller, keyboardType, enable) {
    return Padding(
      padding: const EdgeInsets.only(left: 15, top: 10),
      child: Padding(
        padding: const EdgeInsets.only(left: 10, right: 10),
        child: Center(
          child: TextFormField(
              controller: controller,
              enabled: enable,
              keyboardType: keyboardType,
              decoration: InputDecoration(
                labelText: hintname,
                fillColor: Colors.white,
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide(
                    color: Colors.blue,
                  ),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide(
                    color: Colors.black,
                    width: 1.0,
                  ),
                ),
              )),
        ),
      ),
    );
  }
}

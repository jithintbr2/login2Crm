import 'package:crm_admin/addClientInfoModel.dart';
import 'package:crm_admin/clientDetails.dart';
import 'package:crm_admin/httpService.dart';
import 'package:flutter/material.dart';

import 'addClientModel.dart';
import 'common.dart';

class AddClients extends StatefulWidget {
  String? token;
  AddClients(this.token);
  @override
  _AddClientsState createState() => _AddClientsState();
}

class _AddClientsState extends State<AddClients> {
  TextEditingController name = new TextEditingController();
  TextEditingController contact1 = new TextEditingController();
  TextEditingController contact2 = new TextEditingController();
  TextEditingController emailId = new TextEditingController();
  TextEditingController contactPerson = new TextEditingController();
  TextEditingController designation = new TextEditingController();
  TextEditingController address = new TextEditingController();
  TextEditingController description = new TextEditingController();
  TextEditingController gstNumber = new TextEditingController();
  TextEditingController careOff = new TextEditingController();
  TextEditingController remarks = new TextEditingController();
  var clientType;
  var clientCategory;
  AddClientInfoModel? clientInfo;

  void initState() {
    // TODO: implement initState
    super.initState();
    getData();
  }

  getData() async {
    clientInfo = await HttpService.addClientInfo();

    if (clientInfo != null) {
      setState(() {});
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.lightBlue,
          leading: IconButton(
              icon: Icon(Icons.arrow_back, color: Colors.black),
              onPressed: () => Navigator.of(context).pop()),
          title: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Add Client',
                style: TextStyle(
                  color: Colors.black,
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
        ),
        body: clientInfo!=null?Stack(
          children: [
            SingleChildScrollView(
              child: Column(
                children: [
                  Row(
                    children: [
                      Padding(
                        padding:
                            const EdgeInsets.only(left: 24, right: 10, top: 10),
                        child: FormField<String>(
                          builder: (FormFieldState<String> state) {
                            return Container(
                              height: MediaQuery.of(context).size.height * 0.07,
                              width: MediaQuery.of(context).size.width * 0.4,
                              decoration: BoxDecoration(
                                color: Colors.white,
                                border: Border.all(
                                  color: Colors.black,
                                ),
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: DropdownButtonHideUnderline(
                                child: DropdownButton<String>(
                                  isExpanded: true,
                                  hint: Padding(
                                    padding: const EdgeInsets.only(left: 20),
                                    child: Text('Client Type'),
                                  ),
                                  value: clientType,
                                  items: clientInfo!.data!.clientTypes!.map((data) {
                                    return DropdownMenuItem(
                                      value: data.ctId.toString(),
                                      child: Padding(
                                        padding: const EdgeInsets.only(left: 20),
                                        child: Text(data.ctName.toString()),
                                      ),
                                    );
                                  }).toList(),
                                  onChanged: (newValue) {
                                    setState(() {
                                      clientType = newValue;
                                    });
                                    print(clientType);
                                  },
                                ),
                              ),
                            );
                          },
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(right: 10, top: 10),
                        child: FormField<String>(
                          builder: (FormFieldState<String> state) {
                            return Container(
                              height: MediaQuery.of(context).size.height * 0.07,
                              width: MediaQuery.of(context).size.width * 0.45,
                              decoration: BoxDecoration(
                                color: Colors.white,
                                border: Border.all(
                                  color: Colors.black,
                                ),
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: DropdownButtonHideUnderline(
                                child: DropdownButton<String>(
                                  isExpanded: true,
                                  hint: Padding(
                                    padding: const EdgeInsets.only(left: 20),
                                    child: Text('Client Category'),
                                  ),
                                  value: clientCategory,
                                  items: clientInfo!.data!.clientCat!.map((data) {
                                    return DropdownMenuItem(
                                      value: data.ccId.toString(),
                                      child: Padding(
                                        padding: const EdgeInsets.only(left: 20),
                                        child: Padding(
                                          padding: const EdgeInsets.only(left: 20),
                                          child: Text(data.ccName.toString()),
                                        ),
                                      ),
                                    );
                                  }).toList(),
                                  onChanged: (newValue) {
                                    setState(() {
                                      clientCategory = newValue;
                                    });
                                    print(clientCategory);
                                  },
                                ),
                              ),
                            );
                          },
                        ),
                      ),
                    ],
                  ),
                  textFeildFunction('Name', name, TextInputType.text),
                  textFeildFunction(
                      'Contact Number 1', contact1, TextInputType.text),
                  textFeildFunction(
                      'Contact Number 2', contact2, TextInputType.text),
                  textFeildFunction('Email Id', emailId, TextInputType.text),
                  textFeildFunction(
                      'Contact Person', contactPerson, TextInputType.text),
                  textFeildFunction(
                      'Designation', designation, TextInputType.text),
                  textFeildFunction('Address', address, TextInputType.text),
                  textFeildFunction(
                      'Description', description, TextInputType.text),
                  textFeildFunction(
                      'GST Number', gstNumber, TextInputType.text),
                  textFeildFunction('Care Off', careOff, TextInputType.text),
                  textFeildFunction('Remarks', remarks, TextInputType.text),
                  SizedBox(
                    height: 90,
                  )
                ],
              ),
            ),
            Align(
              child: Padding(
                padding: const EdgeInsets.all(0),
                child: Container(
                  height: 50,
                  width: MediaQuery.of(context).size.width * 7,
                  color: Colors.white,
                  child: FlatButton(
                    color: Colors.green,
                    onPressed: () async {
                      if (clientType == null) {
                        Common.toastMessaage(
                            'Choose Client Type', Colors.red);
                      }
                      else if (clientCategory == null) {
                        Common.toastMessaage(
                            'Choose Client Category', Colors.red);
                      }
                      else if (name.text.isEmpty) {
                        Common.toastMessaage(
                            'Client Name cannot be empty', Colors.red);
                      }
                      else if (contact1.text.isEmpty) {
                        Common.toastMessaage(
                            'Contact1  cannot be empty', Colors.red);
                      }
                      else
                        {
                          Common.showProgressDialog(context, "Loading..");

                          AddClientModel object =
                          await HttpService.addClient(
                              clientType,
                              clientCategory,
                              name.text,
                              contact1.text,
                              contact2.text,emailId.text,contactPerson.text,designation.text,
                            address.text,description.text,gstNumber.text,careOff.text,remarks.text,widget.token
                             );
                          if (object.status == true) {
                            Common.toastMessaage(
                                'Added Successfully', Colors.green);
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => ClientDetails(object.data.toString(),widget.token)),
                            );
                          } else {
                            Navigator.pop(context);
                            Common.toastMessaage(
                                'Something Went Wrong', Colors.red);
                          }

                        }
                    },
                    child: Text(
                      'Submit',
                      style: TextStyle(
                          color: Colors.black,
                          fontWeight: FontWeight.bold,
                          fontSize: 20),
                    ),
                  ),
                ),
              ),
              alignment: Alignment.bottomCenter,
            ),
          ],
        ):AlertDialog(
          content: Flex(
            direction: Axis.horizontal,
            children: <Widget>[
              CircularProgressIndicator(),
              Padding(
                padding: EdgeInsets.only(left: 15),
              ),
              Flexible(
                  flex: 8,
                  child: Text(
                    'Wait..',
                    style: TextStyle(
                        fontSize: 16, fontWeight: FontWeight.bold),
                  )),
            ],
          ),
        ));
  }

  textFeildFunction(hintname, controller, keyboardType) {
    return Padding(
      padding: const EdgeInsets.only(left: 15, top: 10),
      child: Padding(
        padding: const EdgeInsets.only(left: 10, right: 10),
        child: Center(
          child: TextFormField(
              controller: controller,
              keyboardType: keyboardType,
              decoration: InputDecoration(
                labelText: hintname,
                fillColor: Colors.white,
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide(
                    color: Colors.blue,
                  ),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide(
                    color: Colors.black,
                    width: 1.0,
                  ),
                ),
              )),
        ),
      ),
    );
  }
}

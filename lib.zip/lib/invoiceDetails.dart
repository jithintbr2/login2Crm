import 'package:flutter/material.dart';
import 'addReceipt.dart';

class InvoiceDetails extends StatefulWidget {
  String? token;
  String? invoiceId;

  InvoiceDetails(this.token, this.invoiceId);

  @override
  _InvoiceDetailsState createState() => _InvoiceDetailsState();
}

class _InvoiceDetailsState extends State<InvoiceDetails> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Colors.lightBlue,
        leading: IconButton(
            icon: Icon(Icons.arrow_back, color: Colors.black),
            onPressed: () => Navigator.of(context).pop()),
        title: Text(
          'Invoice Details',
          style: TextStyle(
            color: Colors.black,
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      body: Stack(
        children: [
          SingleChildScrollView(
            child: Column(
              children: [
                Container(
                    width: MediaQuery.of(context).size.width * 9,
                    height: 100,
                    decoration: new BoxDecoration(
                        image: new DecorationImage(
                      image: new AssetImage("assets/images/invoice_header.jpg"),
                      fit: BoxFit.fill,
                    ))),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(left: 20, top: 5),
                      child: Container(
                        child: Column(
                          children: [
                            Row(
                              children: [
                                Text('Bill To:'),
                                Padding(
                                  padding: const EdgeInsets.only(left: 10),
                                  child: Text('Client Name'),
                                ),
                              ],
                            ),
                            Padding(
                              padding: const EdgeInsets.only(left: 25),
                              child: Text('Address'),
                            )
                          ],
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(right: 20, top: 5),
                      child: Container(
                        child: Column(
                          children: [
                            Text('Number : INV-20'),
                            Text('Date : 25-04-2022'),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
                Container(
                  margin: EdgeInsets.symmetric(vertical: 20),
                  child: Table(
                    columnWidths: {
                      0: FlexColumnWidth(10),
                      1: FlexColumnWidth(20),
                      2: FlexColumnWidth(20),
                      3: FlexColumnWidth(20),
                    },
                    defaultVerticalAlignment: TableCellVerticalAlignment.middle,
                    border: TableBorder.all(
                        color: Colors.black,
                        style: BorderStyle.solid,
                        width: 1),
                    children: [
                      TableRow(children: [
                        Padding(
                          padding: const EdgeInsets.all(8),
                          child: Center(
                              child:
                                  Text('No', style: TextStyle(fontSize: 15.0))),
                        ),
                        Padding(
                          padding: const EdgeInsets.all(8),
                          child: Center(
                              child: Text('Project',
                                  style: TextStyle(fontSize: 15.0))),
                        ),
                        Padding(
                          padding: const EdgeInsets.all(8),
                          child: Center(
                              child: Text('Description',
                                  style: TextStyle(fontSize: 15.0))),
                        ),
                        Padding(
                          padding: const EdgeInsets.all(8),
                          child: Center(
                              child: Text('Amount',
                                  style: TextStyle(fontSize: 15.0))),
                        ),
                      ]),

                      // for(var item in orderDetails.data.orderItems)
                      //
                      //
                      //   TableRow(children: [
                      //     Padding(
                      //       padding: const EdgeInsets.all(5),
                      //       child: Center(
                      //         child: Text(
                      //           item.itemName,
                      //         ),
                      //       ),
                      //     ),
                      //     Padding(
                      //       padding: const EdgeInsets.all(5),
                      //       child: Center(
                      //         child: Text(
                      //           item.itemQuantity,
                      //         ),
                      //       ),
                      //     ),
                      //     Padding(
                      //       padding: const EdgeInsets.all(5),
                      //       child: Center(
                      //         child: Text(
                      //           item.itemCost,
                      //         ),
                      //       ),
                      //     ),
                      //     Padding(
                      //       padding: const EdgeInsets.all(5),
                      //       child: Center(
                      //         child: Text(
                      //           item.totalCost,
                      //         ),
                      //       ),
                      //     ),
                      //     Column(
                      //       children: [
                      //         OutlinedButton(
                      //           onPressed: () {
                      //             editQty.text =item.itemQuantity.toString();
                      //             editAmount.text=item.itemCost;
                      //             showDialog<String>(
                      //               context: context,
                      //               builder: (BuildContext context) => AlertDialog(
                      //                 title: const Text('Edit'),
                      //                 content: Container(
                      //                   height: MediaQuery.of(context).size.height * 0.3,
                      //                   child: Column(
                      //                     crossAxisAlignment: CrossAxisAlignment.start,
                      //                     children: [
                      //                       Text(item.itemName),
                      //                       Padding(
                      //                         padding: EdgeInsets.symmetric(vertical: 10),
                      //                         child: TextField(
                      //                           //obscureText: true,
                      //                           controller: editQty,
                      //                           keyboardType:TextInputType.number,
                      //                           decoration: InputDecoration(
                      //                             border: OutlineInputBorder(),
                      //                             labelText: 'Qty',
                      //                           ),
                      //                         ),
                      //                       ),
                      //                       Padding(
                      //                         padding: EdgeInsets.symmetric(vertical: 10),
                      //                         child: TextField(
                      //                           //obscureText: true,
                      //                           controller: editAmount,
                      //                           keyboardType:TextInputType.number,
                      //                           decoration: InputDecoration(
                      //                             border: OutlineInputBorder(),
                      //                             labelText: 'Amount',
                      //                           ),
                      //                         ),
                      //                       ),
                      //                     ],
                      //                   ),
                      //                 ),
                      //                 actions: <Widget>[
                      //                   TextButton(
                      //                     onPressed: () => Navigator.pop(context, 'Cancel'),
                      //                     child: const Text('Cancel'),
                      //                   ),
                      //                   TextButton(
                      //                     onPressed: () async {
                      //                       if (editQty.text.isEmpty) {
                      //                         Common.toastMessaage(
                      //                             'Quantity cannot be empty', Colors.red);
                      //                       }
                      //                       else if (editAmount.text.isEmpty) {
                      //                         Common.toastMessaage(
                      //                             'Amount cannot be empty', Colors.red);
                      //                       }
                      //                       else
                      //                       {
                      //
                      //                         EditOrderItemModel orderItemEdit = await HttpService.editOrderItems(widget.userId,widget.orderId,item.opId,editQty.text,item.itemQuantity,
                      //                             editAmount.text,item.itemCost,item.commissionPercentage);
                      //
                      //                         if(orderItemEdit.status==true) {
                      //                           Common.toastMessaage(
                      //                               'Update Successfully', Colors.green);
                      //                           Navigator.push(
                      //                             context,
                      //                             MaterialPageRoute(
                      //                                 builder: (context) => OrderDetails(widget.orderId,widget.userName,widget.userId,widget.index,widget.fromDate,widget.toDate)),
                      //                           );
                      //                         }
                      //                         else
                      //                         {
                      //                           Common.toastMessaage(
                      //                               'Something Went Wrong', Colors.red);
                      //                         }
                      //                       }
                      //
                      //                     },
                      //                     child: const Text('OK'),
                      //                   ),
                      //                 ],
                      //               ),
                      //             );
                      //           },
                      //           child:Icon(Icons.edit),
                      //         ),
                      //         OutlinedButton(
                      //           onPressed: ()=>_deleteDialogue(context,widget.orderId,widget.userId,item.opId,item.itemQuantity,item.varientId),
                      //           child:Icon(Icons.delete,color: Colors.red,),
                      //         ),
                      //       ],
                      //     ),
                      //   ]),
                    ],
                  ),
                ),
                // Center(
                //     child: Row(
                //       children: [
                //         Text(
                //           'Add Receipt',
                //           style: TextStyle(
                //               fontSize: 20,
                //               fontWeight: FontWeight.bold,
                //               color: Colors.white),
                //         ),
                //         IconButton(
                //           icon: Icon(Icons.add_box_outlined, color: Colors.black),
                //           onPressed: () => Navigator.push(
                //             context,
                //             MaterialPageRoute(
                //                 builder: (context) => AddReceipt(widget.token,widget.invoiceId
                //                 )),
                //           ),
                //         )
                //       ],
                //     )),
              ],
            ),
          ),
          Align(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Padding(
                  padding: const EdgeInsets.only(left: 10),
                  child: Container(
                    height: 40,
                    width: 150,
                    color: Colors.white,
                    child: FlatButton(
                      color: Colors.green,
                      onPressed: () async {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) =>
                                  AddReceipt(widget.token, widget.invoiceId)),
                        );
                      },
                      child: Text(
                        'Add Receipt',
                        style: TextStyle(
                            color: Colors.black,
                            fontWeight: FontWeight.bold,
                            fontSize: 18),
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(right: 10),
                  child: Container(
                    height: 40,
                    width: 150,
                    color: Colors.white,
                    child: FlatButton(
                      color: Colors.green,
                      onPressed: () async {},
                      child: Text(
                        'Download',
                        style: TextStyle(
                            color: Colors.black,
                            fontWeight: FontWeight.bold,
                            fontSize: 18),
                      ),
                    ),
                  ),
                ),
              ],
            ),
            alignment: Alignment.bottomCenter,
          ),
        ],
      ),
    );
  }
}

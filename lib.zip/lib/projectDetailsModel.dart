class ProjectDetailsModel {
  bool? status;
  String? message;
  Data? data;

  ProjectDetailsModel({this.status, this.message, this.data});

  ProjectDetailsModel.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    message = json['message'];
    data = json['data'] != null ? new Data.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['status'] = this.status;
    data['message'] = this.message;
    if (this.data != null) {
      data['data'] = this.data!.toJson();
    }
    return data;
  }
}

class Data {
  int? projectId;
  String? projectName;
  String? clientName;
  String? email;
  String? gstNo;
  String? createdBy;
  String? projectCost;
  String? amountPaid;
  String? invoiceAmount;
  String? estStart;
  String? estEnd;
  String? remarks;
  String? description;
  String? address1;
  String? address2;
  String? contact1;
  String? contact2;
  String? contactPerson;
  String? designation;
  String? projectType;
  String? clientType;
  String? clientCategory;
  String? status;
  int? balanceAmount;
  String? timeLeft;
  List<Assignments>? assignments;

  Data(
      {this.projectId,
        this.projectName,
        this.clientName,
        this.email,
        this.gstNo,
        this.createdBy,
        this.projectCost,
        this.amountPaid,
        this.invoiceAmount,
        this.estStart,
        this.estEnd,
        this.remarks,
        this.description,
        this.address1,
        this.address2,
        this.contact1,
        this.contact2,
        this.contactPerson,
        this.designation,
        this.projectType,
        this.clientType,
        this.clientCategory,
        this.status,
        this.balanceAmount,
        this.timeLeft,
        this.assignments});

  Data.fromJson(Map<String, dynamic> json) {
    projectId = json['project_id'];
    projectName = json['project_name'];
    clientName = json['client_name'];
    email = json['email'];
    gstNo = json['gst_no'];
    createdBy = json['created by'];
    projectCost = json['project_cost'];
    amountPaid = json['amount_paid'];
    invoiceAmount = json['invoice_amount'];
    estStart = json['est_start'];
    estEnd = json['est_end'];
    remarks = json['remarks'];
    description = json['description'];
    address1 = json['address1'];
    address2 = json['address2'];
    contact1 = json['contact1'];
    contact2 = json['contact2'];
    contactPerson = json['contact_person'];
    designation = json['designation'];
    projectType = json['project_type'];
    clientType = json['client_type'];
    clientCategory = json['client_category'];
    status = json['status'];
    balanceAmount = json['balance_amount'];
    timeLeft = json['time_left'];
    if (json['assignments'] != null) {
      assignments = <Assignments>[];
      json['assignments'].forEach((v) {
        assignments!.add(new Assignments.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['project_id'] = this.projectId;
    data['project_name'] = this.projectName;
    data['client_name'] = this.clientName;
    data['email'] = this.email;
    data['gst_no'] = this.gstNo;
    data['created by'] = this.createdBy;
    data['project_cost'] = this.projectCost;
    data['amount_paid'] = this.amountPaid;
    data['invoice_amount'] = this.invoiceAmount;
    data['est_start'] = this.estStart;
    data['est_end'] = this.estEnd;
    data['remarks'] = this.remarks;
    data['description'] = this.description;
    data['address1'] = this.address1;
    data['address2'] = this.address2;
    data['contact1'] = this.contact1;
    data['contact2'] = this.contact2;
    data['contact_person'] = this.contactPerson;
    data['designation'] = this.designation;
    data['project_type'] = this.projectType;
    data['client_type'] = this.clientType;
    data['client_category'] = this.clientCategory;
    data['status'] = this.status;
    data['balance_amount'] = this.balanceAmount;
    data['time_left'] = this.timeLeft;
    if (this.assignments != null) {
      data['assignments'] = this.assignments!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Assignments {
  int? activityId;
  String? activity;
  String? staffName;
  String? staffImage;
  String? estimatedTime;
  String? completedTime;
  String? timeVarience;
  String? hourlyExpense;
  String? statusName;

  Assignments(
      {this.activityId,
        this.activity,
        this.staffName,
        this.staffImage,
        this.estimatedTime,
        this.completedTime,
        this.timeVarience,
        this.hourlyExpense,
        this.statusName});

  Assignments.fromJson(Map<String, dynamic> json) {
    activityId = json['activity_id'];
    activity = json['activity'];
    staffName = json['staff_name'];
    staffImage = json['staff_image'];
    estimatedTime = json['estimated_time'];
    completedTime = json['completed_time'];
    timeVarience = json['time_varience'];
    hourlyExpense = json['hourly_expense'];
    statusName = json['status_name'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['activity_id'] = this.activityId;
    data['activity'] = this.activity;
    data['staff_name'] = this.staffName;
    data['staff_image'] = this.staffImage;
    data['estimated_time'] = this.estimatedTime;
    data['completed_time'] = this.completedTime;
    data['time_varience'] = this.timeVarience;
    data['hourly_expense'] = this.hourlyExpense;
    data['status_name'] = this.statusName;
    return data;
  }
}
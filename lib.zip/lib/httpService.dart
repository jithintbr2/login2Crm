import 'dart:convert';
import 'package:crm_admin/accountsModel.dart';
import 'package:crm_admin/addClientInfoModel.dart';
import 'package:crm_admin/addExpenseInfoModel.dart';
import 'package:crm_admin/addExpenseModel.dart';
import 'package:crm_admin/addInvoiceModel.dart';
import 'package:crm_admin/addProjectInfoModel.dart';
import 'package:crm_admin/addProjectModel.dart';
import 'package:crm_admin/clientListModel.dart';
import 'package:crm_admin/dashboardModel.dart';
import 'package:crm_admin/expenseListModel.dart';
import 'package:crm_admin/loginModel.dart';
import 'package:crm_admin/projectDetailsModel.dart';
import 'package:crm_admin/projectListModel.dart';
import 'package:crm_admin/quickAddModel.dart';

import 'package:dio/dio.dart';
import 'StaffListModel.dart';
import 'addClientModel.dart';
import 'addInvoiceInfoModel.dart';
import 'addQuickInfoModel.dart';
import 'addReceiptInfoModel.dart';
import 'addReceiptModel.dart';
import 'clientDetailsModel.dart';
import 'clientProjectsModel.dart';
import 'invoiceListModel.dart';
import 'receiptListModel.dart';

class HttpService {
  static Dio _dio = Dio();
   static final baseUrl = "https://login2.co.in/test_crm/mobile_app_api/";
  //static final baseUrl = "https://login2.co.in/work_management_system/mobile_app_api/";

  static Future login(uanemVar, pass) async {
    var params = {"username": uanemVar, "password": pass, "firebaseId": '123'};
    try {
      var result = await _dio.get(baseUrl + "login", queryParameters: params);
      print(params);
      print(result);

      LoginModel model = LoginModel.fromJson(result.data);

      return model;
    } catch (Exception) {
      return null;
    }
  }

  static Future dashboard(token) async {
    var params = {
      "token": token,
    };
    try {
      var result =
          await _dio.get(baseUrl + "dashboard", queryParameters: params);

      DashboardModel model = DashboardModel.fromJson(result.data);

      return model;
    } catch (Exception) {
      return null;
    }
  }

  static Future projectList(token) async {
    var params = {
      "token": token,
    };
    try {
      var result =
          await _dio.get(baseUrl + "project_list", queryParameters: params);

      ProjectListModel model = ProjectListModel.fromJson(result.data);

      return model;
    } catch (Exception) {
      return null;
    }
  }

  static Future clientList(token) async {
    var params = {
      "token": token,
    };
    try {
      var result =
          await _dio.get(baseUrl + "client_list", queryParameters: params);

      ClientListModel model = ClientListModel.fromJson(result.data);

      return model;
    } catch (Exception) {
      return null;
    }
  }

  static Future staffList(token) async {
    var params = {
      "token": token,
    };
    try {
      var result =
          await _dio.get(baseUrl + "staff_list", queryParameters: params);

      StaffListModel model = StaffListModel.fromJson(result.data);

      return model;
    } catch (Exception) {
      return null;
    }
  }

  static Future projectDetails(projectId, token) async {
    var params = {
      "projectId": projectId,
      "token": token,
    };
    try {
      var result =
          await _dio.get(baseUrl + "project_details", queryParameters: params);

      ProjectDetailsModel model = ProjectDetailsModel.fromJson(result.data);

      return model;
    } catch (Exception) {
      return null;
    }
  }

  static Future accounts(token, menuId) async {
    var params = {
      "menu_id": menuId,
      "token": token,
    };
    try {
      var result =
          await _dio.get(baseUrl + "submenus", queryParameters: params);

      AccountsModel model = AccountsModel.fromJson(result.data);

      return model;
    } catch (Exception) {
      return null;
    }
  }

  static Future clientDetails(clientId, token) async {
    var params = {
      "clientId": clientId,
      "token": token,
    };
    try {
      var result =
          await _dio.get(baseUrl + "client_details", queryParameters: params);
      ClientDetailsModel model = ClientDetailsModel.fromJson(result.data);
      return model;
    } catch (Exception) {
      return null;
    }
  }

  static Future addClientInfo() async {
    try {
      var result = await _dio.get(
        baseUrl + "client_add_info",
      );
      AddClientInfoModel model = AddClientInfoModel.fromJson(result.data);
      return model;
    } catch (Exception) {
      return null;
    }
  }

  static Future addClient(
      clientType,
      clientCategory,
      name,
      contact1,
      contact2,
      emailId,
      contactPerson,
      designation,
      address,
      description,
      gstNumber,
      careOff,
      remarks,
      token) async {
    var params = {
      "token": token,
      "clientName": name,
      "address": address,
      "contact1": contact1,
      "contact2": contact2,
      "clientType": clientType,
      "clientCategory": clientCategory,
      "contactPerson": contactPerson,
      "designation": designation,
      "email": emailId,
      "description": description,
      "remarks": remarks,
      "careOf": careOff,
      "gstNo": gstNumber,
    };
    try {
      var result =
          await _dio.get(baseUrl + "add_client", queryParameters: params);
      AddClientModel model = AddClientModel.fromJson(result.data);
      return model;
    } catch (Exception) {
      return null;
    }
  }

  static Future addProjectInfo() async {
    try {
      var result = await _dio.get(
        baseUrl + "project_add_info",
      );
      AddProjectInfoModel model = AddProjectInfoModel.fromJson(result.data);
      return model;
    } catch (Exception) {
      return null;
    }
  }

  static Future addProjects(
      projectName,
      client,
      description,
      cost,
      remarks,
      totalAmount,
      paidAmount,
      projectType,
      status,
      estimatedFromDate,
      estimatedToDate,
      isGst,
      isInvoice,
      token) async {
    var params = {
      "token": token,
      "projectName": projectName,
      "gstCheck": isGst,
      "gstAmount": totalAmount,
      "generateInvoice": isInvoice,
      "projectType": projectType,
      "client": client,
      "cost": cost,
      "status": status,
      "startDate": estimatedFromDate,
      "endDate": estimatedToDate,
      "remarks": remarks,
      "description": description,
      "paidAmount": paidAmount,
    };

    try {
      var result =
          await _dio.get(baseUrl + "add_project", queryParameters: params);
      AddProjectModel model = AddProjectModel.fromJson(result.data);
      return model;
    } catch (Exception) {
      return null;
    }
  }

  static Future addExpenseInfo() async {
    try {
      var result = await _dio.get(
        baseUrl + "add_expense_details",
      );
      AddExpenseInfoModel model = AddExpenseInfoModel.fromJson(result.data);
      return model;
    } catch (Exception) {
      return null;
    }
  }

  static Future addExpense(
      fromAccount, expenseType, amount, person, date, remarks, token) async {
    var params = {
      "token": token,
      "fromAccount": fromAccount,
      "type": expenseType,
      "amount": amount,
      "toAccount": person,
      "remark": remarks,
      "expenseDate": date,
    };

    try {
      var result =
          await _dio.get(baseUrl + "add_expense", queryParameters: params);
      AddExpenseModel model = AddExpenseModel.fromJson(result.data);
      return model;
    } catch (Exception) {
      return null;
    }
  }
  static Future expenseList(token) async {
    var params = {
      "token": token,
    };
    try {
      var result =
      await _dio.get(baseUrl + "expense_list", queryParameters: params);

      ExpenseListModel model = ExpenseListModel.fromJson(result.data);

      return model;
    } catch (Exception) {
      return null;
    }
  }
  static Future addQuickInfo() async {
    try {
      var result = await _dio.get(
        baseUrl + "quick_add_info",
      );
      AddQuickInfoModel model = AddQuickInfoModel.fromJson(result.data);
      return model;
    } catch (Exception) {
      return null;
    }
  }
  static Future quickAdd(clientName,contactNumber,projectName,projectType,projectCost,advance,token) async {
    var params = {
      "token": token,
       "client_name": clientName,
      "contact_number": contactNumber,
      "project_name": projectName,
      "cost": projectCost,
      "cash_received": advance,
      "prj_type": projectType,
    };
    print(params);
  try {
      var result = await _dio.get(baseUrl + "quick_add", queryParameters: params);
      print(result);

      QuickAddModel model = QuickAddModel.fromJson(result.data);
      return model;
    } catch (Exception) {
      return null;
    }
  }
  static Future invoiceList(token) async {
    var params = {
      "token": token,
    };
    try {
      var result =
      await _dio.get(baseUrl + "invoice_list", queryParameters: params);

      InvoiceListModel model = InvoiceListModel.fromJson(result.data);

      return model;
    } catch (Exception) {
      return null;
    }
  }
  static Future receiptList(token) async {
    var params = {
      "token": token,
    };
    try {
      var result =
      await _dio.get(baseUrl + "receipt_list", queryParameters: params);

      ReceiptListModel model = ReceiptListModel.fromJson(result.data);

      return model;
    } catch (Exception) {
      return null;
    }
  }
  static Future addInvoiceInfo() async {
    try {
      var result = await _dio.get(
        baseUrl + "invoice_add_info",
      );
      AddInvoiceInfoModel model = AddInvoiceInfoModel.fromJson(result.data);
      return model;
    } catch (Exception) {
      return null;
    }
  }
  static Future clientProjects(clientId) async {
    var params = {
      "client_id": clientId,
    };
    try {
      var result =
      await _dio.get(baseUrl + "get_client_projects", queryParameters: params);
print(result);
      ClientProjectsModel model = ClientProjectsModel.fromJson(result.data);

      return model;
    } catch (Exception) {
      return null;
    }
  }
  static Future addInvoice(body) async {
   // print(body);
    var params = {
      "data": body,
    };
    try {
      var result = await _dio.post(baseUrl + "add_invoice", data: jsonEncode(body));
      print(body);

      AddInvoiceModel model = AddInvoiceModel.fromJson(result.data);

      return model;
    } catch (Exception) {
      return null;
    }
  }
  static Future AddReceiptInfo(invoiceId) async {
    var params = {
      "invoice_id": invoiceId,
    };
    try {
      var result =
      await _dio.get(baseUrl + "add_receipt_info", queryParameters: params);

      AddReciptInfoModel model = AddReciptInfoModel.fromJson(result.data);

      return model;
    } catch (Exception) {
      return null;
    }
  }
  static Future addReceipt(body) async {
    // print(body);
    var params = {
      "data": body,
    };
    try {
      var result = await _dio.post(baseUrl + "add_receipt", data: jsonEncode(body));
      print(body);

      AddReceiptModel model = AddReceiptModel.fromJson(result.data);

      return model;
    } catch (Exception) {
      return null;
    }
  }
}

import 'package:crm_admin/addExpenseInfoModel.dart';
import 'package:crm_admin/addExpenseModel.dart';
import 'package:date_time_picker/date_time_picker.dart';
import 'package:flutter/material.dart';

import 'common.dart';
import 'httpService.dart';

class AddExpense extends StatefulWidget {
  String? token;

  AddExpense(this.token);

  @override
  _AddExpenseState createState() => _AddExpenseState();
}

class _AddExpenseState extends State<AddExpense> {
  TextEditingController amount = new TextEditingController();
  TextEditingController remarks = new TextEditingController();
  String? fromAccount;
  var expenseType;
  var person;
  String? date;
  AddExpenseInfoModel? expenseInfo;


  void initState() {
    // TODO: implement initState
    super.initState();
    getData();
  }

  getData() async {
    fromAccount = await Common.getSharedPref("userId");
    expenseInfo = await HttpService.addExpenseInfo();

    if (expenseInfo != null) {
      setState(() {});
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.lightBlue,
          leading: IconButton(
              icon: Icon(Icons.arrow_back, color: Colors.black),
              onPressed: () => Navigator.of(context).pop()),
          title: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Add Expense',
                style: TextStyle(
                  color: Colors.black,
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
        ),
        body: expenseInfo != null
            ? Stack(
                children: [
                  SingleChildScrollView(
                    child: Column(
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(
                              left: 24, right: 10, top: 10),
                          child: FormField<String>(
                            builder: (FormFieldState<String> state) {
                              return Container(
                                height:
                                    MediaQuery.of(context).size.height * 0.07,
                                width: MediaQuery.of(context).size.width * 0.9,
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  border: Border.all(
                                    color: Colors.black,
                                  ),
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: DropdownButtonHideUnderline(
                                  child: DropdownButton<String>(
                                    isExpanded: true,


                                    hint: Padding(
                                      padding: const EdgeInsets.only(left: 20),
                                      child: Text('From Account'),
                                    ),
                                    value: fromAccount,
                                    items: expenseInfo!.data!.fromAccount!
                                        .map((data) {
                                      return DropdownMenuItem(
                                        value: data.fromId.toString(),
                                        child:
                                            Padding(
                                              padding: const EdgeInsets.only(left: 10),
                                              child: Row(
                                                children: [
                                                  Icon(Icons.account_balance,color: Colors.blue,),
                                                  SizedBox(width: 10,),
                                                  Text(data.fromStaffName.toString()),
                                                ],
                                              ),
                                            ),
                                      );
                                    }).toList(),
                                    onChanged: (newValue) {
                                      setState(() {
                                        fromAccount = newValue;
                                      });
                                      print(fromAccount);
                                    },
                                  ),
                                ),
                              );
                            },
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(
                              left: 24, right: 10, top: 10),
                          child: FormField<String>(
                            builder: (FormFieldState<String> state) {
                              return Container(
                                height:
                                    MediaQuery.of(context).size.height * 0.07,
                                width: MediaQuery.of(context).size.width * 0.9,
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  border: Border.all(
                                    color: Colors.black,
                                  ),
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: DropdownButtonHideUnderline(
                                  child: DropdownButton<String>(
                                    isExpanded: true,
                                    hint: Padding(
                                      padding: const EdgeInsets.only(left: 10),
                                      child: Row(
                                        children: [
                                          Icon(Icons.account_balance,color: Colors.blue,),
                                          SizedBox(width: 10,),
                                          Text('Expense Type'),
                                        ],
                                      ),
                                    ),
                                    value: expenseType,
                                    items: expenseInfo!.data!.expenseType!
                                        .map((data) {
                                      return DropdownMenuItem(
                                        value: data.typeId.toString(),
                                        child: Padding(
                                          padding: const EdgeInsets.only(left: 10),
                                          child: Row(
                                            children: [
                                              Icon(Icons.description,color: Colors.blue,),
                                              SizedBox(width: 10,),
                                              Text(data.typeName.toString()),
                                            ],
                                          ),
                                        ),
                                      );
                                    }).toList(),
                                    onChanged: (newValue) {
                                      setState(() {
                                        expenseType = newValue;
                                      });
                                      print(expenseType);
                                    },
                                  ),
                                ),
                              );
                            },
                          ),
                        ),
                        textFeildFunction(
                            'Amount', amount, TextInputType.number,Icon(Icons.monetization_on,color: Colors.blue,)),
                        Padding(
                          padding: const EdgeInsets.only(
                              left: 24, right: 10, top: 10),
                          child: FormField<String>(
                            builder: (FormFieldState<String> state) {
                              return Container(
                                height:
                                    MediaQuery.of(context).size.height * 0.07,
                                width: MediaQuery.of(context).size.width * 0.9,
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  border: Border.all(
                                    color: Colors.black,
                                  ),
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: DropdownButtonHideUnderline(
                                  child: DropdownButton<String>(
                                    isExpanded: true,
                                    hint: Padding(
                                      padding: const EdgeInsets.only(left: 10),
                                      child: Row(
                                        children: [
                                          Icon(Icons.person,color: Colors.blue,),
                                          SizedBox(width: 10,),
                                          Text('Person/Company'),
                                        ],
                                      ),
                                    ),
                                    value: person,
                                    items: expenseInfo!.data!.toAccount!
                                        .map((data) {
                                      return DropdownMenuItem(
                                        value: data.toId.toString(),
                                        child:
                                            Padding(
                                              padding: const EdgeInsets.only(left: 10),
                                              child: Row(
                                                children: [
                                                  Icon(Icons.person,color: Colors.blue,),
                                                  SizedBox(width: 10,),
                                                  Text(data.toStaffName.toString()),
                                                ],
                                              ),
                                            ),
                                      );
                                    }).toList(),
                                    onChanged: (newValue) {
                                      setState(() {
                                        person = newValue;
                                      });
                                      print(person);
                                    },
                                  ),
                                ),
                              );
                            },
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.only(left: 10, top: 10),
                          child: Container(
                            height: MediaQuery.of(context).size.height * 0.07,
                            width: MediaQuery.of(context).size.width * 0.9,
                            decoration: BoxDecoration(
                              color: Colors.white,
                              border: Border.all(
                                color: Colors.black,
                              ),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Center(
                              child: DateTimePicker(
                                initialValue: date,
                                icon:Padding(
                                  padding: const EdgeInsets.only(left: 10),
                                  child: Icon(Icons.calendar_today_outlined,color: Colors.blue,),
                                ),



                                type: DateTimePickerType.date,
                                dateHintText: 'From Date',
                                //controller: fromDate,
                                firstDate: DateTime(1995),
                                lastDate:
                                    DateTime.now().add(Duration(days: 365)),
                                // This will add one year from current date
                                validator: (value) {
                                  return null;
                                },
                                onChanged: (value) {
                                  if (value.isNotEmpty) {
                                    setState(() {
                                      date = value;
                                    });
                                  }
                                },
                                // We can also use onSaved
                                onSaved: (value) {
                                  if (value!.isNotEmpty) {
                                    date = value;
                                  }
                                },
                              ),
                            ),
                          ),
                        ),
                        textFeildFunction(
                            'Remarks', remarks, TextInputType.text,Icon(Icons.list,color: Colors.blue,)),
                        SizedBox(
                          height: 90,
                        )
                      ],
                    ),
                  ),
                  Align(
                    child: Padding(
                      padding: const EdgeInsets.all(0),
                      child: Container(
                        height: 50,
                        width: MediaQuery.of(context).size.width * 7,
                        color: Colors.white,
                        child: FlatButton(
                          color: Colors.green,
                          onPressed: () async {
                            if (fromAccount == null) {
                              Common.toastMessaage(
                                  'Choose From Account', Colors.red);
                            } else if (expenseType == null) {
                              Common.toastMessaage(
                                  'Choose Expense Type', Colors.red);
                            } else if (amount.text.isEmpty) {
                              Common.toastMessaage(
                                  'Expense Amount Can not Empty', Colors.red);
                            } else if (person == null) {
                              Common.toastMessaage(
                                  'Choose Person/Company', Colors.red);
                            } else if (date == null) {
                              Common.toastMessaage('Choose Date', Colors.red);
                            } else {
                              Common.showProgressDialog(context, "Loading..");

                              AddExpenseModel object =
                                  await HttpService.addExpense(
                                      fromAccount,
                                      expenseType,
                                      amount.text,
                                      person,
                                      date,
                                      remarks.text,
                                      widget.token);
                              if (object.status == true) {
                                Common.toastMessaage(
                                    'Added Successfully', Colors.green);
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) =>
                                          AddExpense(widget.token)),
                                );
                              } else {
                                Navigator.pop(context);
                                Common.toastMessaage(
                                    'Something Went Wrong', Colors.red);
                              }
                            }
                          },
                          child: Text(
                            'Submit',
                            style: TextStyle(
                                color: Colors.black,
                                fontWeight: FontWeight.bold,
                                fontSize: 20),
                          ),
                        ),
                      ),
                    ),
                    alignment: Alignment.bottomCenter,
                  ),
                ],
              )
            : AlertDialog(
                content: Flex(
                  direction: Axis.horizontal,
                  children: <Widget>[
                    CircularProgressIndicator(),
                    Padding(
                      padding: EdgeInsets.only(left: 15),
                    ),
                    Flexible(
                        flex: 8,
                        child: Text(
                          'Wait..',
                          style: TextStyle(
                              fontSize: 16, fontWeight: FontWeight.bold),
                        )),
                  ],
                ),
              ));
  }

  textFeildFunction(hintName, controller, keyboardType,icon) {
    return Padding(
      padding: const EdgeInsets.only(left: 15, top: 10),
      child: Padding(
        padding: const EdgeInsets.only(left: 10, right: 10),
        child: Center(
          child: TextFormField(
              controller: controller,
              keyboardType: keyboardType,
              decoration: InputDecoration(
                prefixIcon:icon,
                labelText: hintName,
                fillColor: Colors.white,
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide(
                    color: Colors.blue,
                  ),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide(
                    color: Colors.black,
                    width: 1.0,
                  ),
                ),
              )),
        ),
      ),
    );
  }
}

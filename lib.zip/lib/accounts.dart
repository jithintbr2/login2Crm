import 'package:crm_admin/accountsModel.dart';
import 'package:crm_admin/addExpense.dart';
import 'package:crm_admin/expenseList.dart';
import 'package:crm_admin/httpService.dart';
import 'package:crm_admin/invoiceLis.dart';
import 'package:crm_admin/receiptList.dart';
import 'package:flutter/material.dart';

import 'debitCredit.dart';

class Accounts extends StatefulWidget {
  String? menuId;
  String? token;

  Accounts(this.menuId, this.token);

  @override
  _AccountsState createState() => _AccountsState();
}

class _AccountsState extends State<Accounts> {
  AccountsModel? accounts;

  void initState() {
    // TODO: implement initState
    super.initState();
    getData();
  }

  getData() async {
    accounts = await HttpService.accounts(widget.token, widget.menuId);
    if (accounts != null) {
      setState(() {});
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.lightBlue,
        leading: IconButton(
            icon: Icon(Icons.arrow_back, color: Colors.black),
            onPressed: () => Navigator.of(context).pop()),
        title: Text(
          'Accounts',
          style: TextStyle(
            color: Colors.black,
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      body: accounts != null
          ? SafeArea(
              child: SingleChildScrollView(
              child: Padding(
                padding: const EdgeInsets.only(top: 50),
                child: GridView.builder(
                  physics: const NeverScrollableScrollPhysics(),
                  shrinkWrap: true,
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 3,
                  ),
                  padding: EdgeInsets.zero,
                  itemCount: accounts!.data!.submenus!.length,
                  itemBuilder: (BuildContext context, index) {
                    return InkWell(
                      onTap: () async {
                        if (accounts!.data!.submenus![index].appPage ==
                            'invoice_list') {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => InvoiceList(widget.token)),
                          );
                        }
                        else if (accounts!.data!.submenus![index].appPage =='view_expense') {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => ExpenseList(widget.token)),
                          );
                        }
                        else if (accounts!.data!.submenus![index].appPage =='add_expense') {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => AddExpense(widget.token)),
                          );
                        }
                        else if (accounts!.data!.submenus![index].appPage =='view_receipt') {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => ReceiptList(widget.token)),
                          );
                        }

                        
                        else if (accounts!.data!.submenus![index].appPage =='view_debit_credit') {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => DebitCredit()),
                          );
                        }
                      },
                      child: GestureDetector(
                        child: Container(
                          constraints: const BoxConstraints(
                            maxHeight: 81,
                          ),
                          child: Column(
                            children: [
                              Container(
                                constraints: const BoxConstraints(
                                  minHeight: 56,
                                  minWidth: 56,
                                  maxHeight: 69,
                                  maxWidth: 69,
                                ),
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(12),
                                  image: DecorationImage(
                                      fit: BoxFit.cover,
                                      image: AssetImage(
                                          'assets/images/project1.jpg')),
                                ),
                              ),
                              const SizedBox(
                                height: 4,
                              ),
                              Expanded(
                                child: Text(
                                  accounts!.data!.submenus![index].submenuTitle
                                      .toString(),
                                  style: TextStyle(fontWeight: FontWeight.bold),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),
            ))
          : AlertDialog(
              content: Flex(
                direction: Axis.horizontal,
                children: <Widget>[
                  CircularProgressIndicator(),
                  Padding(
                    padding: EdgeInsets.only(left: 15),
                  ),
                  Flexible(
                      flex: 8,
                      child: Text(
                        'Wait..',
                        style: TextStyle(
                            fontSize: 16, fontWeight: FontWeight.bold),
                      )),
                ],
              ),
            ),
    );
  }
}

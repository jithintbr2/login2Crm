class AddClientInfoModel {
  bool? status;
  String? message;
  Data? data;

  AddClientInfoModel({this.status, this.message, this.data});

  AddClientInfoModel.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    message = json['message'];
    data = json['data'] != null ? new Data.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['status'] = this.status;
    data['message'] = this.message;
    if (this.data != null) {
      data['data'] = this.data!.toJson();
    }
    return data;
  }
}

class Data {
  List<ClientTypes>? clientTypes;
  List<ClientCat>? clientCat;

  Data({this.clientTypes, this.clientCat});

  Data.fromJson(Map<String, dynamic> json) {
    if (json['client_types'] != null) {
      clientTypes = <ClientTypes>[];
      json['client_types'].forEach((v) {
        clientTypes!.add(new ClientTypes.fromJson(v));
      });
    }
    if (json['client_cat'] != null) {
      clientCat = <ClientCat>[];
      json['client_cat'].forEach((v) {
        clientCat!.add(new ClientCat.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.clientTypes != null) {
      data['client_types'] = this.clientTypes!.map((v) => v.toJson()).toList();
    }
    if (this.clientCat != null) {
      data['client_cat'] = this.clientCat!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class ClientTypes {
  String? ctId;
  String? ctName;

  ClientTypes({this.ctId, this.ctName});

  ClientTypes.fromJson(Map<String, dynamic> json) {
    ctId = json['ct_id'];
    ctName = json['ct_name'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['ct_id'] = this.ctId;
    data['ct_name'] = this.ctName;
    return data;
  }
}

class ClientCat {
  String? ccId;
  String? ccName;

  ClientCat({this.ccId, this.ccName});

  ClientCat.fromJson(Map<String, dynamic> json) {
    ccId = json['cc_id'];
    ccName = json['cc_name'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['cc_id'] = this.ccId;
    data['cc_name'] = this.ccName;
    return data;
  }
}

class ProjectListModel {
  bool? status;
  String? message;
  Data? data;

  ProjectListModel({this.status, this.message, this.data});

  ProjectListModel.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    message = json['message'];
    data = json['data'] != null ? new Data.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['status'] = this.status;
    data['message'] = this.message;
    if (this.data != null) {
      data['data'] = this.data!.toJson();
    }
    return data;
  }
}

class Data {
  List<ProjectList>? projectList;

  Data({this.projectList});

  Data.fromJson(Map<String, dynamic> json) {
    if (json['projectList'] != null) {
      projectList = <ProjectList>[];
      json['projectList'].forEach((v) {
        projectList!.add(new ProjectList.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.projectList != null) {
      data['projectList'] = this.projectList!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class ProjectList {
  int? projectId;
  String? projectName;
  String? clientName;
  String? statusName;
  String? startDate;
  String? completedDate;
  String? timeLeft;

  ProjectList(
      {this.projectId,
        this.projectName,
        this.clientName,
        this.statusName,
        this.startDate,
        this.completedDate,
        this.timeLeft});

  ProjectList.fromJson(Map<String, dynamic> json) {
    projectId = json['projectId'];
    projectName = json['projectName'];
    clientName = json['clientName'];
    statusName = json['statusName'];
    startDate = json['startDate'];
    completedDate = json['completedDate'];
    timeLeft = json['timeLeft'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['projectId'] = this.projectId;
    data['projectName'] = this.projectName;
    data['clientName'] = this.clientName;
    data['statusName'] = this.statusName;
    data['startDate'] = this.startDate;
    data['completedDate'] = this.completedDate;
    data['timeLeft'] = this.timeLeft;
    return data;
  }
}
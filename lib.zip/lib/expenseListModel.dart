class ExpenseListModel {
  bool? status;
  String? message;
  Data? data;

  ExpenseListModel({this.status, this.message, this.data});

  ExpenseListModel.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    message = json['message'];
    data = json['data'] != null ? new Data.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['status'] = this.status;
    data['message'] = this.message;
    if (this.data != null) {
      data['data'] = this.data!.toJson();
    }
    return data;
  }
}

class Data {
  String? totalExpense;
  List<Expense>? expense;

  Data({this.totalExpense, this.expense});

  Data.fromJson(Map<String, dynamic> json) {
    totalExpense = json['totalExpense'];
    if (json['expense'] != null) {
      expense = <Expense>[];
      json['expense'].forEach((v) {
        expense!.add(new Expense.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['totalExpense'] = this.totalExpense;
    if (this.expense != null) {
      data['expense'] = this.expense!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Expense {
  int? id;
  String? expenseHead;
  String? date;
  String? remarks;
  String? amount;
  String? fromAccount;

  Expense(
      {this.id,
        this.expenseHead,
        this.date,
        this.remarks,
        this.amount,
        this.fromAccount});

  Expense.fromJson(Map<String, dynamic> json) {
    id = json['Id'];
    expenseHead = json['expenseHead'];
    date = json['date'];
    remarks = json['Remarks'];
    amount = json['Amount'];
    fromAccount = json['fromAccount'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['Id'] = this.id;
    data['expenseHead'] = this.expenseHead;
    data['date'] = this.date;
    data['Remarks'] = this.remarks;
    data['Amount'] = this.amount;
    data['fromAccount'] = this.fromAccount;
    return data;
  }
}